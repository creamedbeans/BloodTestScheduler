package bloodtests;

import java.util.Comparator;

public class PatientComparator implements Comparator<Patient> {  //comparator for  ordering patients in PQ
    @Override
    public int compare(Patient p1, Patient p2) {
        // change priority levels to values 
        int priority1 = getPriorityValue(p1.getPriority());
        int priority2 = getPriorityValue(p2.getPriority());

        // handles invalid cases
        if (priority1 == -1 || priority2 == -1) {
            throw new IllegalArgumentException("Invalid priority: " + p1.getPriority() + " or " + p2.getPriority());
        }

        // compares by priority
        if (priority1 != priority2) {
            return Integer.compare(priority2, priority1); // Higher first
        }

        // if same prio, then higher prio to patients from hospital
        if (p1.isFromHospitalWard() != p2.isFromHospitalWard()) {
            return Boolean.compare(p2.isFromHospitalWard(), p1.isFromHospitalWard()); // True (hospital) first
        }
        return 0;
    }

    //method to convert prio labels to numbers
    private int getPriorityValue(String priority) {
        if (priority == null) return -1; // null case

        switch (priority.trim().toLowerCase()) {
            case "urgent":  //highest prio
                return 3;
            case "medium":  // middle prio
                return 2;
            case "low":     //lowest prio
                return 1;
            default:
                return -1; // invalid case
        }
    }
}
