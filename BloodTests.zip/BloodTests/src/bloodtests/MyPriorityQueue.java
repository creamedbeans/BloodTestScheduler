package bloodtests;

import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections; //

//PQ for managing patient in order
public class MyPriorityQueue {
    PriorityQueue<Patient> queue = new PriorityQueue<>(new PatientComparator());  //declare PQ and orders them based on PatientComparator



    public MyPriorityQueue() {
        queue = new PriorityQueue<>(new PatientComparator());
    }

    // add patient to PQ
    public void addPatient(Patient patient) {
        queue.add(patient);  //add to Queue
        
        List<Patient> tempList = new ArrayList<>(queue);  //PQ to list to sort
        Collections.sort(tempList, new PatientComparator());
        queue.clear();  //clear queueu
        queue.addAll(tempList); //add sorted patients
    }

    // get next patient for blood test 
    public Patient getNextPatient() {
        return queue.poll(); // remove + return highest prio patient
    }

    
    // check to see if queue is empty
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    // get size of queue
    public int getSize() {
        return queue.size();
    }
    
    // retrive patients from PQ
    public List<Patient> getAllPatients() {
        return new ArrayList<>(queue); // convert PQ to list
        
    }

    public void removePatient(Patient patient) {
        queue.remove(patient); //remove patient from PQ
    }
    
    
}
