package bloodtests;

public class Patient {
    //storing patient details
    private String name;
    private String priority; // urgent, medium, low
    private int age;
    private boolean fromHospitalWard;
    private String gpName; 
    private String clinicName; 

    public Patient(String name, String priority, int age, boolean fromHospitalWard, String gpDetails) {
        this.name = name;  // stores users name, prioriy, age, from hospital or not, gp name and clinic name
        this.priority = priority;
        this.age = age;
        this.fromHospitalWard = fromHospitalWard;
        this.gpName = gpName; 
        this.clinicName = clinicName; 
    
}
    //getter to get name
    public String getName() {
        return name;
    }

    //getter to get prio
    public String getPriority() {
        return priority;
    }

    //getter to get age
    public int getAge() {
        return age;
    }

    //getter to check if from hospital or not
    public boolean isFromHospitalWard() {
        return fromHospitalWard;
    }
    
    //getter for gp name
    public String getGpName() { 
        return gpName;
    }
    
    //getter for CLinic name
    public String getClinicName() { 
        return clinicName;
    }
}
