package bloodtests;

import java.util.LinkedList;
import java.util.Queue;

public class NoShowTracker {
    private Queue<Patient> noShowQueue; // queue storing last 5 no shows
    private static final int MAX_NO_SHOWS = 5;  //max size of list

    //init queue and adds 5 default no shows
    public NoShowTracker() {
        noShowQueue = new LinkedList<>();
        
        // add default no shows
        addNoShow(new Patient("Jesse", "Medium", 40, false, "Dr. Green"));
        addNoShow(new Patient("Brock", "Low", 35, false, "Dr. Brown"));
        addNoShow(new Patient("James", "Urgent", 50, true, "Dr. Black"));
        addNoShow(new Patient("Misty", "Medium", 45, false, "Dr. White"));
        addNoShow(new Patient("Ash", "Low", 38, false, "Dr. Gray"));
    }

    // add patient to no show list
    public final void addNoShow(Patient patient) {
        if (noShowQueue.size() >= MAX_NO_SHOWS) {
            noShowQueue.poll(); // removes oldest in queue when new one get put in
        }
        noShowQueue.add(patient);  //add no show patient
    }

    // list for no show patients
    public Queue<Patient> getNoShows() {
        return new LinkedList<>(noShowQueue); 
    }
}
