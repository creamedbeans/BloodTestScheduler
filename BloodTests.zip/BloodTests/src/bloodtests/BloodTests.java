package bloodtests; //project package definition

//main class
public class BloodTests {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //runs gui on play button pressed
                new RegisterGUI().setVisible(true); 
            }
        });
    }
}